'''
Title:  马原期末复习题库
Author: Frozen (https://github.com/AlterFrozen)
Date:   2022/1/1
Intro:  本题库包含期末重点考察章节的选择题
'''

from core import APP

if __name__ == "__main__":
    print(__doc__)
    APP.start()